# POC scope and acceptance criteria

## Product hypothesis
A French staffing recruiter can validate a candidate's role-related declarations through a scripted conversational interview with human review, without automatically assessing suitability.

## v0.1 In scope
- One fixed job: warehouse order picker
- Local AI text-based Q&A (Ollama Qwen3:0.6b)
- Lightweight on-screen speaking character + browser TTS
- 8 candidate turns maximum
- One-click factual record export
- Scripted no-LLM mode

## Out of scope
- Photorealistic avatar, live microphone speech-to-text, live video, ATS, database, user accounts, actual applicant testing, ranking or scoring, deployment

## Acceptance
1. With Ollama running, interview produces a first question and a relevant follow-up.
2. With demo mode enabled, the interface works even if Ollama is offline.
3. Candidate can finish at any time.
4. Export contains only interview transcript and technical metadata; no evaluation.
5. Server defaults to 127.0.0.1, and no candidate data is written to disk server-side.

## Next technical experiments
- Local offline STT via whisper.cpp small/tiny
- Local French TTS via Kokoro/Piper (verify voice licenses)
- VRM/Three.js with permitted avatar model and lip sync
- Measure peak RAM and response latency on 8 GB Mac

## Risks
- Browser speech synthesis may download or remotely process voices depending on browser/system.
- Tiny language model can hallucinate and ask inappropriate questions. Test with synthetic data; improve deterministic question gates before any real usage.
- Home hosting requires hardened security and reliable power/network; never expose this POC over a public port.
