"""Local-only recruitment interview proof of concept. Python 3.10+ stdlib."""
import json, os, pathlib, urllib.request, urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
ROOT = pathlib.Path(__file__).parent
HOST = os.getenv('HOST','127.0.0.1')
PORT = int(os.getenv('PORT','8765'))
MODEL = os.getenv('OLLAMA_MODEL','qwen3:0.6b')
OLLAMA = os.getenv('OLLAMA_URL','http://127.0.0.1:11434/api/chat')
MAX_TURNS = 8
SYSTEM = '''Tu es un assistant d'entretien de démonstration pour un poste de préparateur de commandes. Tu es une IA et tu l'as clairement annoncé. Pose UNE question ouverte à la fois, puis une courte relance contextuelle si pertinente. Questions utiles: expérience factuelle, disponibilité professionnelle, certifications liées au poste, contraintes horaires et motivation. N'interroge jamais sur la santé, l'âge, la famille, l'origine, la religion, le handicap ni sur d'autres caractéristiques protégées. Ne note pas, ne classe pas, ne recommande pas d'embauche ou de rejet. Réponds uniquement en français, en 1 à 2 phrases, sans balises de raisonnement. Ne demande pas d'informations personnelles inutiles.'''
QUESTIONS = [
 'Pouvez-vous me raconter votre expérience professionnelle liée à la préparation de commandes ?',
 'Quelles tâches avez-vous effectuées en entrepôt ou en logistique ?',
 'Avez-vous des habilitations ou certifications utiles pour ce poste ? Si oui, lesquelles ?',
 'À partir de quand seriez-vous disponible pour commencer ?',
 'Quels types d’horaires de travail recherchez-vous ?',
 'Qu’est-ce qui vous intéresse dans ce poste ?',
 'Y a-t-il un élément professionnel important que vous souhaiteriez ajouter ?',
]
class Handler(BaseHTTPRequestHandler):
 def send_json(self, code, payload):
  data=json.dumps(payload,ensure_ascii=False).encode()
  self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
 def do_GET(self):
  p=urlparse(self.path).path
  if p=='/api/health': return self.send_json(200,{'ok':True,'model':MODEL,'mode':'local'})
  if p=='/':p='/index.html'
  file=(ROOT/'public'/p.lstrip('/')).resolve()
  if not file.is_relative_to((ROOT/'public').resolve()) or not file.is_file():return self.send_error(404)
  data=file.read_bytes();mime={'.html':'text/html; charset=utf-8','.js':'application/javascript','.css':'text/css'}.get(file.suffix,'application/octet-stream')
  self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def do_POST(self):
  if self.path!='/api/next':return self.send_error(404)
  if int(self.headers.get('Content-Length','0'))>30000:return self.send_json(413,{'error':'Payload too large'})
  try:
   body=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))))
   history=body.get('history',[])
   if not isinstance(history,list) or len(history)>30:raise ValueError('Historique invalide')
   turns=sum(1 for h in history if h.get('role')=='user')
   if turns>=MAX_TURNS:return self.send_json(200,{'done':True,'reply':'Merci pour cet échange. Un recruteur humain pourra examiner les réponses que vous décidez de lui transmettre.'})
   if body.get('demo'):
    return self.send_json(200,{'reply':QUESTIONS[min(turns,len(QUESTIONS)-1)],'done':False,'mode':'scripted'})
   msgs=[{'role':'system','content':SYSTEM}]+[{'role':h['role'],'content':str(h['content'])[:1500]} for h in history if h.get('role') in ('user','assistant')]
   if not history:msgs.append({'role':'user','content':'Commence en te présentant comme une IA, puis pose ta première question.'})
   payload=json.dumps({'model':MODEL,'messages':msgs,'stream':False,'think':False,'options':{'num_ctx':2048,'num_predict':120,'temperature':0.4}}).encode()
   req=urllib.request.Request(OLLAMA,data=payload,headers={'Content-Type':'application/json'},method='POST')
   with urllib.request.urlopen(req,timeout=90) as r:response=json.load(r)
   reply=response['message']['content'].strip()
   import re
   reply=re.sub(r'<think>.*?</think>','',reply,flags=re.S).strip()
   return self.send_json(200,{'reply':reply or QUESTIONS[min(turns,len(QUESTIONS)-1)],'done':False,'mode':'ollama'})
  except (urllib.error.URLError,TimeoutError) as e:return self.send_json(503,{'error':'Ollama indisponible. Lance « ollama serve » et télécharge le modèle, ou utilise le mode démo.','detail':str(e)[:200]})
  except (ValueError,KeyError,TypeError,json.JSONDecodeError) as e:return self.send_json(400,{'error':str(e)[:300]})
 def log_message(self,fmt,*args): pass
if __name__=='__main__':
 print(f'RecruitAI POC: http://{HOST}:{PORT} | model={MODEL}')
 ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
