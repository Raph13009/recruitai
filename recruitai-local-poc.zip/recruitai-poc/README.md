# RecruitAI POC — local-first, no paid APIs

A deliberately small **technical proof of concept**, not a recruitment product. Runs on a Mac with 8 GB RAM. No Node dependencies, no Python packages. Source code is public-ready, but **no personal candidate data should be committed or used**.

## Features
- French interview with a local Qwen3 model via Ollama
- Offline scripted demo mode when Ollama is not available
- Lightweight animated 2D interviewer (browser rendered, **not photorealistic**)
- Speech output using browser `speechSynthesis` (local processing is **not guaranteed by browser/OS**)
- Text input; no microphone/transcription yet (intentionally avoids opaque cloud STT)
- Factual transcript export, no scoring/ranking or automated rejection
- In-memory only; binds to localhost by default

## Quick start (macOS)
1. Install [Ollama](https://ollama.com/download) and Python 3.10+.
2. In a terminal: `ollama pull qwen3:0.6b` (~523 MB). Alternative stronger model: `ollama pull qwen3:1.7b` (~1.4 GB), set `OLLAMA_MODEL=qwen3:1.7b`.
3. Start Ollama (`ollama serve` if not already running).
4. From the repository folder: `python3 server.py`.
5. Open **http://127.0.0.1:8765**. Check **Mode démo sans Ollama** to try it with no model.

No API keys. The Ollama inference call targets localhost. The app never intentionally contacts a cloud API. Ollama and browser/OS components have their own update, telemetry, and voice behavior, so do not claim the *whole computer* is offline unless verified.

## Security and compliance
- Experimental only. Use synthetic candidate answers.
- No authentication, rate-limits, HTTPS, audit log, deletion workflow, consent management, or production hardening.
- Never expose the current server directly to the internet or use with real candidates.
- Recruitment AI can be high-risk under the EU AI Act depending on actual use; human-only decision-making does not automatically exempt a system.
- Public repository must never include interview recordings, applicant data, secrets, or private resumes.

## Roadmap
- [ ] Add local microphone capture + offline transcription using whisper.cpp `tiny` or `base` (~40–150 MB weights)
- [ ] Replace basic avatar with open-source VRM model rendered in Three.js; verify avatar asset license separately
- [ ] Compare Qwen 0.6B vs 1.7B for instruction-following, language and interview relevance
- [ ] Add consent / accessibility controls and explicit exit path
- [ ] Build human-reviewed extraction into structured factual fields (not candidate ranking)
- [ ] Evaluate home server GPU and availability before optional real-time photorealistic avatar

## Architecture
`Browser HTML/CSS/JS → Python stdlib HTTP → Ollama localhost (Qwen3)`

No browser microphone in v0.1. Browser TTS is a convenience feature, not a proven offline engine. For fully offline vocal I/O, use a local speech engine such as Piper/Kokoro and local whisper.cpp.

## Public GitHub repository creation (requires GitHub CLI login)

```bash
git init
git add .
git commit -m "Initial local RecruitAI proof of concept"
gh auth login
gh repo create recruitai-local-poc --public --source=. --remote=origin --push
```

Check privacy and legal implications **before** publishing any additional assets or data. No real candidate data is present in this starter repo.

## License
MIT for the code in this repository. External models, tools and avatar assets are licensed separately.
